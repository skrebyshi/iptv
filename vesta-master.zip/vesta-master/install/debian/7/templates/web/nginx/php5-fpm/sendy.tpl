server {
    listen      %ip%:%web_port%;
    server_name %domain_idn% %alias_idn%;
    root        %docroot%;
    index       index.php index.html index.htm;
    access_log  /var/log/nginx/domains/%domain%.log combined;
    access_log  /var/log/nginx/domains/%domain%.bytes bytes;
    error_log   /var/log/nginx/domains/%domain%.error.log error;

    location = /favicon.ico {
        log_not_found off;
        access_log off;
    }

    location = /robots.txt {
        allow all;
        log_not_found off;
        access_log off;
    }

    location ~* "/\.(htaccess|htpasswd|git|svn|DS_Store)$" {
        deny all;
    }

    location ~ /(readme.html|license.txt) {
        deny all;
    }

    if (!-f $request_filename){
        rewrite ^/([a-zA-Z0-9-]+)$ /$1.php last;
    }

    location / {
        try_files $uri $uri/ /index.php?$args;
        location ~* ^.+\.(ogg|ogv|svg|svgz|swf|eot|otf|woff|mov|mp3|mp4|webm|flv|ttf|rss|atom|jpg|jpeg|gif|png|ico|bmp|mid|midi|wav|rtf|css|js|jar|pdf)$ {
            expires 1d;
        }

        location ~ [^/]\.php(/|$) {
            fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
            try_files $uri =404;
            fastcgi_pass %backend_lsnr%;
            fastcgi_index index.php;
            include /etc/nginx/fastcgi_params;
        }

        location /l/ {
            rewrite ^/l/([a-zA-Z0-9/]+)$ /l.php?i=$1 last;
        }

        location /t/ {
            rewrite ^/t/([a-zA-Z0-9/]+)$ /t.php?i=$1 last;
        }

        location /w/ {
            rewrite ^/w/([a-zA-Z0-9/]+)$ /w.php?i=$1 last;
        }

        location /unsubscribe/ {
            rewrite ^/unsubscribe/(.*)$ /unsubscribe.php?i=$1 last;
        }

        location /subscribe/ {
            rewrite ^/subscribe/(.*)$ /subscribe.php?i=$1 last;
        }
    }

    error_page  403 /error/404.html;
    error_page  404 /error/404.html;
    error_page  500 502 503 504 /error/50x.html;

    location /error/ {
        alias   %home%/%user%/web/%domain%/document_errors/;
    }

    location /vstats/ {
        alias   %home%/%user%/web/%domain%/stats/;
        include %home%/%user%/web/%domain%/stats/auth.conf*;
    }

    include     /etc/nginx/conf.d/phpmyadmin.inc*;
    include     /etc/nginx/conf.d/phppgadmin.inc*;
    include     /etc/nginx/conf.d/webmail.inc*;

    include     %home%/%user%/conf/web/nginx.%domain%.conf*;
}
