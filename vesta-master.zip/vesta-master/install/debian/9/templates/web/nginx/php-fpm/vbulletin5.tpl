server {
    listen      %ip%:%web_port%;
    server_name %domain_idn% %alias_idn%;
    root        %docroot%;
    index       index.php index.html index.htm;
    access_log  /var/log/nginx/domains/%domain%.log combined;
    access_log  /var/log/nginx/domains/%domain%.bytes bytes;
    error_log   /var/log/nginx/domains/%domain%.error.log error;
    location = /favicon.ico {
        log_not_found off;
        access_log off;
    }

    location = /robots.txt {
        allow all;
        log_not_found off;
        access_log off;
    }

    # legacy css being handled separate for performance
    location = /css\.php {
        rewrite ^ /core/css.php break;
    }

    # make install available from presentation
    location ^~ /install {
        rewrite ^/install/ /core/install/ break;
    }

    # any request to not existing item gets redirected through routestring
    location / {
        if (!-f $request_filename) {
            rewrite ^/(.*)$ /index.php?routestring=$1 last;
        }

        location ~* ^.+\.(jpeg|jpg|png|gif|bmp|ico|svg|css|js)$ {
            expires     max;
        }

    }

    # make admincp available from presentation
    location ^~ /admincp {
        if (!-f $request_filename) {
            rewrite ^/admincp/(.*)$ /index.php?routestring=admincp/$1 last;
        }
    }

    # process any php scripts, not found gets redirected through routestring
    location ~ \.php$ {
    # handles legacy scripts
        if (!-f $request_filename) {
            rewrite ^/(.*)$ /index.php?routestring=$1 break;
        }

        fastcgi_split_path_info ^(.+\.php)(.*)$;
        fastcgi_pass %backend_lsnr%;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_param QUERY_STRING $query_string;
        fastcgi_param REQUEST_METHOD $request_method;
        fastcgi_param CONTENT_TYPE $content_type;
        fastcgi_param CONTENT_LENGTH $content_length;
        fastcgi_intercept_errors on;
        fastcgi_ignore_client_abort off;
        fastcgi_connect_timeout 60;
        fastcgi_send_timeout 180;
        fastcgi_read_timeout 180;
        fastcgi_buffers 256 16k;
        fastcgi_buffer_size 32k;
        fastcgi_temp_file_write_size 256k;

        include /etc/nginx/fastcgi_params;
    }

    error_page  403 /error/404.html;
    error_page  404 /error/404.html;
    error_page  500 502 503 504 /error/50x.html;

    location /error/ {
        alias   %home%/%user%/web/%domain%/document_errors/;
    }

    location ~* "/\.(htaccess|htpasswd)$" {
        deny    all;
        return  404;
    }

    location /vstats/ {
        alias   %home%/%user%/web/%domain%/stats/;
        include %home%/%user%/web/%domain%/stats/auth.conf*;
    }

    include     /etc/nginx/conf.d/phpmyadmin.inc*;
    include     /etc/nginx/conf.d/phppgadmin.inc*;
    include     /etc/nginx/conf.d/webmail.inc*;

    include     %home%/%user%/conf/web/nginx.%domain_idn%.conf*;
}
